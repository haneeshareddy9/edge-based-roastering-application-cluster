import calendar

dat= ['1', '2']

print(int(dat[0]))
